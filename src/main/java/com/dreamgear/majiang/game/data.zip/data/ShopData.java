package com.football.game.data;

public class ShopData {
	
	private int position;/*"商品位置"*/
	
	private float odds;//概率
	
	private String poolid;//对应奖池
	
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public float getOdds() {
		return odds;
	}
	public void setOdds(float odds) {
		this.odds = odds;
	}
	public String getPoolid() {
		return poolid;
	}
	public void setPoolid(String poolid) {
		this.poolid = poolid;
	}
	
	
	
}
