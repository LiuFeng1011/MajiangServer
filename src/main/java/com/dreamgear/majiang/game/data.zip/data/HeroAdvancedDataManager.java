package com.football.game.data;

import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HeroAdvancedDataManager {
	static final Logger logger = LoggerFactory.getLogger(HeroAdvancedDataManager.class);

	private HashMap<String,HeroAdvancedData> dataMap = new HashMap<String,HeroAdvancedData>();

	/**
	 * 载入固化数据
	 * @param path
	 * @throws Exception
	 */
	public void load(String path) throws Exception {
		List<Object> list = GameDataManager.loadData(path, HeroAdvancedData.class,"hero_advanced");
		
		for (Object obj : list) {
			HeroAdvancedData data = (HeroAdvancedData) obj;
			
			if(!dataMap.containsKey(data.getHeroid())){
				dataMap.put(data.getHeroid(),data);
			}
			
		}
	}
	
	public HeroAdvancedData GetData(String heroid){
		if(dataMap.containsKey(heroid)){
			return dataMap.get(heroid);
		}
		return null;
	}
	
}
