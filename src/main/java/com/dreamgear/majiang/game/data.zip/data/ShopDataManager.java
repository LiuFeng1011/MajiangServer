package com.football.game.data;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ShopDataManager {
	static final Logger logger = LoggerFactory.getLogger(ShopDataManager.class);
	
	private List<ShopData> dataList = new ArrayList<ShopData>();
	/**
	 * 载入固化数据
	 * @param path
	 * @throws Exception
	 */
	public void load(String path) throws Exception {
		
		List<Object> list = GameDataManager.loadData(path, ShopData.class,"shop_normal");
		
		for (Object obj : list) {
			ShopData data = (ShopData) obj;
			dataList.add(data);
		}
	}
	
	public List<ShopData> getDataList() {
		return dataList;
	}
	public void setDataList(List<ShopData> dataList) {
		this.dataList = dataList;
	}
	
}
