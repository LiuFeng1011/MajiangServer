package com.football.game.data;

public class HeroAdvancedData {
	private String	heroid	;	/*	英雄编号	*/
	private int	hero_quality	;	/*	进阶等级	*/
	private String	equip_id1	;	/*	装备1	*/
	private String	equip_id2	;	/*	装备2	*/
	private String	equip_id3	;	/*	装备3	*/
	private String	equip_id4	;	/*	装备4	*/
	private String	equip_id5	;	/*	装备5	*/
	private String	equip_id6	;	/*	装备6	*/
	private int	strength	;	/*	力量	*/
	private int	intelligence	;	/*	智力	*/
	private int	agility	;	/*	敏捷	*/
	private int	speed	;	/*	速度	*/
	private int	hp	;	/*	最大生命值	*/
	private int	atk_phy	;	/*	物理攻击力	*/
	private int	atk_magic	;	/*	魔法强度	*/
	private int	pef_phy	;	/*	物理护甲	*/
	private int	pef_magic	;	/*	魔法抗性	*/
	private int	crit_phy	;	/*	物理暴击	*/
	private int	crit_magic	;	/*	魔法暴击	*/
	private int	acc	;	/*	命中	*/
	private int	avoid	;	/*	闪避	*/
	private int	ignore_pef_phy	;	/*	穿透物理护甲	*/
	private int	ignore_pef_magic	;	/*	魔抗穿透	*/
	private int	vampireLv	;	/*	吸血等级	*/
	private int	treatmentup	;	/*	治疗效果提升	*/
	private int	ignore_silence	;	/*	抵抗沉默几率	*/
	private int	anger_remain	;	/*	能量消耗降低	*/
	
	public String GetEquipIDByIndex(int index){
		switch(index){
		case 0 : 
			return equip_id1;
		case 1 : 
			return equip_id2;
		case 2 : 
			return equip_id3;
		case 3 : 
			return equip_id4;
		case 4 : 
			return equip_id5;
		case 5 : 
			return equip_id6;
			default :
				return "-1";
		}
	}
	
	public String getHeroid() {
		return heroid;
	}
	public void setHeroid(String heroid) {
		this.heroid = heroid;
	}
	public int getHero_quality() {
		return hero_quality;
	}
	public void setHero_quality(int hero_quality) {
		this.hero_quality = hero_quality;
	}
	public String getEquip_id1() {
		return equip_id1;
	}
	public void setEquip_id1(String equip_id1) {
		this.equip_id1 = equip_id1;
	}
	public String getEquip_id2() {
		return equip_id2;
	}
	public void setEquip_id2(String equip_id2) {
		this.equip_id2 = equip_id2;
	}
	public String getEquip_id3() {
		return equip_id3;
	}
	public void setEquip_id3(String equip_id3) {
		this.equip_id3 = equip_id3;
	}
	public String getEquip_id4() {
		return equip_id4;
	}
	public void setEquip_id4(String equip_id4) {
		this.equip_id4 = equip_id4;
	}
	public String getEquip_id5() {
		return equip_id5;
	}
	public void setEquip_id5(String equip_id5) {
		this.equip_id5 = equip_id5;
	}
	public String getEquip_id6() {
		return equip_id6;
	}
	public void setEquip_id6(String equip_id6) {
		this.equip_id6 = equip_id6;
	}
	public int getStrength() {
		return strength;
	}
	public void setStrength(int strength) {
		this.strength = strength;
	}
	public int getIntelligence() {
		return intelligence;
	}
	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}
	
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getAgility() {
		return agility;
	}
	public void setAgility(int agility) {
		this.agility = agility;
	}
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public int getAtk_phy() {
		return atk_phy;
	}
	public void setAtk_phy(int atk_phy) {
		this.atk_phy = atk_phy;
	}
	public int getAtk_magic() {
		return atk_magic;
	}
	public void setAtk_magic(int atk_magic) {
		this.atk_magic = atk_magic;
	}
	public int getPef_phy() {
		return pef_phy;
	}
	public void setPef_phy(int pef_phy) {
		this.pef_phy = pef_phy;
	}
	public int getPef_magic() {
		return pef_magic;
	}
	public void setPef_magic(int pef_magic) {
		this.pef_magic = pef_magic;
	}
	public int getCrit_phy() {
		return crit_phy;
	}
	public void setCrit_phy(int crit_phy) {
		this.crit_phy = crit_phy;
	}
	public int getCrit_magic() {
		return crit_magic;
	}
	public void setCrit_magic(int crit_magic) {
		this.crit_magic = crit_magic;
	}
	public int getAcc() {
		return acc;
	}
	public void setAcc(int acc) {
		this.acc = acc;
	}
	public int getAvoid() {
		return avoid;
	}
	public void setAvoid(int avoid) {
		this.avoid = avoid;
	}
	public int getIgnore_pef_phy() {
		return ignore_pef_phy;
	}
	public void setIgnore_pef_phy(int ignore_pef_phy) {
		this.ignore_pef_phy = ignore_pef_phy;
	}
	public int getIgnore_pef_magic() {
		return ignore_pef_magic;
	}
	public void setIgnore_pef_magic(int ignore_pef_magic) {
		this.ignore_pef_magic = ignore_pef_magic;
	}
	public int getVampireLv() {
		return vampireLv;
	}
	public void setVampireLv(int vampireLv) {
		this.vampireLv = vampireLv;
	}
	public int getTreatmentup() {
		return treatmentup;
	}
	public void setTreatmentup(int treatmentup) {
		this.treatmentup = treatmentup;
	}
	public int getIgnore_silence() {
		return ignore_silence;
	}
	public void setIgnore_silence(int ignore_silence) {
		this.ignore_silence = ignore_silence;
	}
	public int getAnger_remain() {
		return anger_remain;
	}
	public void setAnger_remain(int anger_remain) {
		this.anger_remain = anger_remain;
	}
	
	
	
}
