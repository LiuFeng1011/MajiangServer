package com.dreamgear.majiang.game.log;

import com.dreamgear.majiang.db.DBManager;
import com.dreamgear.majiang.game.player.PlayerManager;
import com.dreamgear.majiang.utils.TimeUtils;

public class LogData {
	long uid =-1;//玩家uid
	long time;//日志记录时间
	int gold = 0;//玩家持有钱数
	long createtime = 0;//玩家首次登录时间
	
	int eventid;//事件id
	int eventtype = 0;//事件类型
	String eventvalue = "";//参数
	
	public long getUid() {
		return uid;
	}
	public void setUid(long uid) {
		this.uid = uid;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public int getGold() {
		return gold;
	}
	public void setGold(int gold) {
		this.gold = gold;
	}
	public long getCreatetime() {
		return createtime;
	}
	public void setCreatetime(long createtime) {
		this.createtime = createtime;
	}
	public int getEventid() {
		return eventid;
	}
	public void setEventid(int eventid) {
		this.eventid = eventid;
	}
	public int getEventtype() {
		return eventtype;
	}
	public void setEventtype(int eventtype) {
		this.eventtype = eventtype;
	}
	public String getEventvalue() {
		return eventvalue;
	}
	public void setEventvalue(String eventvalue) {
		this.eventvalue = eventvalue;
	}
	
	public static void AddLog(PlayerManager pm,int eventid,int eventtype,String eventvalue){
		LogData ld = new LogData();
		if(pm != null){
			ld.setUid(pm.getPd().getUid());
			ld.setGold(pm.getPd().getGold());
			ld.setCreatetime(pm.getPd().getCreateTime());
		}
		
		ld.setTime(TimeUtils.nowLong());
		ld.setEventid(eventid);
		ld.setEventtype(eventtype);
		ld.setEventvalue(eventvalue);
		
		DBManager.getInstance().getLogDAO().addLogData(ld);
		
	}
	
}
