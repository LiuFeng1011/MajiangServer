package com.dreamgear.majiang.game.server.resp;

import java.util.ArrayList;
import java.util.List;

import com.dreamgear.majiang.game.game.GameResult;
import com.dreamgear.majiang.game.server.protocol.GameProtocol;
import com.dreamgear.majiangserver.net.BaseMessage;

public class InGameOverResp extends BaseMessage {
	public GameResult result;
	public List<List<String>> playerBrandList = new ArrayList<List<String>>();
	public List<List<Integer>> resultMap;//胡牌玩家的牌 已分组
	
	public int GetProtocol() {
		// TODO Auto-generated method stub
		return GameProtocol.GAME_OVER;
	}
	
	public InGameOverResp(GameResult result){
		this.result = result;
	}
}
