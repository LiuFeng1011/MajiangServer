package com.dreamgear;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.dreamgear.majiang.common.GameConst;
import com.dreamgear.http.handler.impl.WXNotify;
import com.dreamgear.majiang.common.GameCommon;
import com.dreamgear.majiang.common.GameConfig;
import com.dreamgear.majiang.common.GameCommon.enDelegateState;
import com.dreamgear.majiang.db.DBManager;
import com.dreamgear.majiang.delegate.DelegateData;
import com.dreamgear.majiang.delegate.DelegateIncomeData;
import com.dreamgear.majiang.delegate.DelegateManager;
import com.dreamgear.majiang.game.data.GameDataManager;
import com.dreamgear.majiang.game.order.OrderData;
import com.dreamgear.majiang.utils.HttpUtils;
import com.dreamgear.majiang.utils.TimeUtils;

public class test {
private static final Logger logger = LoggerFactory.getLogger(MajiangApp.class);
	
    public static void main( String[] args ) throws Exception
    {
		//数据库
//		DBManager.getInstance().init();

		//游戏配置
//		GameConfig.load();
		
//    	String URL = "http://vurl.cn/create.php";
//    	String field = "http://wx.qlogo.cn/mmopen/ajNVdqHZLLB8xRrT4zn9ZNGs6";
//    	String encodefield = java.net.URLEncoder.encode(field, "UTF-8");
//    	String user_info = HttpUtils.GetHttpData(URL, "url="+encodefield, "POST");
//		logger.info("user_info : " + user_info);
    	
    	List<Integer> list = new ArrayList<Integer>();
    	for(int i = 0 ;i < 10 ; i ++){
    		list.add(i+10);
    	}
    	
    	list = list.subList(0, 2);
    	
    	logger.info("list : " + JSON.toJSONString(list));
    }
}
