package com.dreamgear.majiang.game.server.protocol;

public class GameModuleType {

	//测试模块
	public static final int TEST = 0x0000;//test
	public static final int MODULE_PLAYER = 0x0001;//用户数据

}
