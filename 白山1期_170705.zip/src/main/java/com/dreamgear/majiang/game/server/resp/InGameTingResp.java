package com.dreamgear.majiang.game.server.resp;

import com.dreamgear.majiangserver.net.BaseMessage;

public class InGameTingResp extends BaseMessage {
	public long index;//玩家id
}
