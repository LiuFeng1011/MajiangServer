package com.dreamgear.majiang.game.log;

public class LogEventID {
	public static final int EVE_PLAYER_LOGIN = 10001;//玩家登录游戏 type 0 非首次  1首次
	public static final int EVE_ONLINE_COUNT = 20001;//实时在线人数
}
