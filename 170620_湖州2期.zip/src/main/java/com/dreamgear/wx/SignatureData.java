package com.dreamgear.wx;

public class SignatureData {

	public String token;
	public long tokenTime ;
	
	public String ticket ;
	public long ticketTime ;
	
	public String noncestr;
}
