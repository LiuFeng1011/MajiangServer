package com.dreamgear.majiang.game.data;

public class IapData {
	private int id;//id
	private int price;//价格（RMB）
	private int count;//钻石
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
}
