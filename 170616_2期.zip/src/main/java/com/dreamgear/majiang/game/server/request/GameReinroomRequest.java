package com.dreamgear.majiang.game.server.request;

import com.dreamgear.majiang.game.server.protocol.GameProtocol;

public class GameReinroomRequest {
	public int GetProtocol() {
		// TODO Auto-generated method stub
		return GameProtocol.GMAE_REINROOM;
	}
}
