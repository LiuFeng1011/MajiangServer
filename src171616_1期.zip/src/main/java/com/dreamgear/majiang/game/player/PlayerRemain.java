package com.dreamgear.majiang.game.player;

public class PlayerRemain {
	int id;
	int dru;//当日新增人数
	
	//留存率
	int day_1;
	int day_2;
	int day_3;
	int day_4;
	int day_5;
	int day_6;
	int day_7;
	int day_14;
	int day_30;
	
	long stat_time;//统计目标日期
	long add_time;//添加日期
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getDru() {
		return dru;
	}
	public void setDru(int dru) {
		this.dru = dru;
	}
	public int getDay_1() {
		return day_1;
	}
	public void setDay_1(int day_1) {
		this.day_1 = day_1;
	}
	public int getDay_2() {
		return day_2;
	}
	public void setDay_2(int day_2) {
		this.day_2 = day_2;
	}
	public int getDay_3() {
		return day_3;
	}
	public void setDay_3(int day_3) {
		this.day_3 = day_3;
	}
	public int getDay_4() {
		return day_4;
	}
	public void setDay_4(int day_4) {
		this.day_4 = day_4;
	}
	public int getDay_5() {
		return day_5;
	}
	public void setDay_5(int day_5) {
		this.day_5 = day_5;
	}
	public int getDay_6() {
		return day_6;
	}
	public void setDay_6(int day_6) {
		this.day_6 = day_6;
	}
	public int getDay_7() {
		return day_7;
	}
	public void setDay_7(int day_7) {
		this.day_7 = day_7;
	}
	public int getDay_14() {
		return day_14;
	}
	public void setDay_14(int day_14) {
		this.day_14 = day_14;
	}
	public int getDay_30() {
		return day_30;
	}
	public void setDay_30(int day_30) {
		this.day_30 = day_30;
	}
	public long getStat_time() {
		return stat_time;
	}
	public void setStat_time(long stat_time) {
		this.stat_time = stat_time;
	}
	public long getAdd_time() {
		return add_time;
	}
	public void setAdd_time(long add_time) {
		this.add_time = add_time;
	}
	
	
}
