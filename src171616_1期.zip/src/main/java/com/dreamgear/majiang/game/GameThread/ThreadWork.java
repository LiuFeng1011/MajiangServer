package com.dreamgear.majiang.game.GameThread;

public interface ThreadWork {
	public void doWork();
}
