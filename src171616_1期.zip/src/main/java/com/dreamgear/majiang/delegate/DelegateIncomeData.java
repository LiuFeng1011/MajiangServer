package com.dreamgear.majiang.delegate;

public class DelegateIncomeData {
	String date;//日期
	int uv;//新增用户
	int ordercount;//订单
	int valuecount;//金额
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getUv() {
		return uv;
	}
	public void setUv(int uv) {
		this.uv = uv;
	}
	public int getOrdercount() {
		return ordercount;
	}
	public void setOrdercount(int ordercount) {
		this.ordercount = ordercount;
	}
	public int getValuecount() {
		return valuecount;
	}
	public void setValuecount(int valuecount) {
		this.valuecount = valuecount;
	}
	
}
