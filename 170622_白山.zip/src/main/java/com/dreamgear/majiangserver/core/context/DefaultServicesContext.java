package com.dreamgear.majiangserver.core.context;

import java.io.File;

public class DefaultServicesContext extends DefaultDGContext{

	public DefaultServicesContext() throws Exception {
		super("./config/");
		// TODO Auto-generated constructor stub
	}

}
