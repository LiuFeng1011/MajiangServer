package com.dreamgear.http.handler.domain;

public class GMFunctionRetData {
	public int code;
	public String errmsg;
	public String data;
}
