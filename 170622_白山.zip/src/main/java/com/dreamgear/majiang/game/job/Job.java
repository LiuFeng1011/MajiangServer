package com.dreamgear.majiang.game.job;

public class Job {

}
