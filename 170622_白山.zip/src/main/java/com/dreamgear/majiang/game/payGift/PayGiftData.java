package com.dreamgear.majiang.game.payGift;

public class PayGiftData {
	private int payid;
	private int gift;
	public int getPayid() {
		return payid;
	}
	public void setPayid(int payid) {
		this.payid = payid;
	}
	public int getGift() {
		return gift;
	}
	public void setGift(int gift) {
		this.gift = gift;
	}
	
	
}
