package com.dreamgear.majiang.game.server.resp;

import com.dreamgear.majiangserver.net.BaseMessage;

public class BaseResp extends BaseMessage{
	public int pindex = -1;
}
