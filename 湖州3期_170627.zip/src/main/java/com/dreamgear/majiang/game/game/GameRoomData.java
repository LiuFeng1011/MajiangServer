package com.dreamgear.majiang.game.game;

public class GameRoomData {
	public int openRoom = 0;//有效房间数
	public int playingRoom = 0;//正在游戏的房间数
}
